# Patrol Log — Deploy Instructions

## Step 1: Delete old Vercel project
- Go to vercel.com → your project → Settings → scroll to bottom → Delete Project

## Step 2: Clear your GitHub repo
- Go to github.com → patrol-log repository
- Delete ALL existing files in the repo

## Step 3: Upload these files to GitHub
Upload everything from this zip. Final structure must be EXACTLY:

  patrol-app/
  ├── package.json
  ├── public/
  │   ├── index.html
  │   └── manifest.json
  └── src/
      ├── index.js
      └── App.jsx

IMPORTANT: Do NOT include vite.config.js or vercel.json — leave those out completely.

## Step 4: Deploy on Vercel
1. vercel.com → Add New Project
2. Select your patrol-log repository
3. On the configuration screen:
   - Framework Preset: Create React App
   - Root Directory: . (leave blank/dot)
   - Leave all other settings as default
4. Click Deploy
5. Wait ~2 minutes for build to complete

## Step 5: Add to iPhone home screen
1. Open your .vercel.app URL in Safari
2. Tap Share (box with arrow)
3. Tap "Add to Home Screen"
4. Tap Add

## Admin login
Email: acurtis175@yahoo.com  
Password: marlborough1
