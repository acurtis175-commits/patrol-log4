# Patrol Log — Deploy Instructions

## Step 1: Clear everything old
- Delete your old Vercel project:
  vercel.com → project → Settings → scroll to bottom → Delete Project
- On GitHub, delete ALL files in your patrol-log repository

## Step 2: Upload these files to GitHub
Drag ALL files from this zip into your GitHub repo.
Final structure must be EXACTLY this:

  ├── .nvmrc
  ├── index.html
  ├── package.json
  ├── vite.config.js
  ├── vercel.json
  ├── public/
  │   └── manifest.json
  └── src/
      ├── main.jsx
      └── App.jsx

## Step 3: Deploy on Vercel
1. vercel.com → Add New Project
2. Import your patrol-log GitHub repository
3. On the Build & Output Settings screen:
   - Framework Preset: Vite
   - Build Command: npm run build
   - Output Directory: dist
   - Install Command: npm install
   - Node.js Version: 18.x  ← SET THIS in the dropdown
4. Click Deploy
5. Build takes about 90 seconds

## Step 4: Add to iPhone home screen
1. Open your .vercel.app URL in Safari (must be Safari, not Chrome)
2. Tap the Share icon (box with upward arrow at bottom of screen)
3. Scroll down and tap "Add to Home Screen"
4. Tap "Add" in the top right

## Updating the app in future
1. Ask Claude for changes → get updated App.jsx
2. Go to GitHub → src/App.jsx → click pencil icon → paste new code → Commit
3. Vercel auto-redeploys in ~60 seconds

## Admin credentials
Email:    acurtis175@yahoo.com
Password: marlborough1
